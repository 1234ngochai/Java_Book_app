package com.fit2081.myfirstproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onButtonClick(View view){
        EditText Title = findViewById(R.id.Title);
        EditText Price = findViewById(R.id.Price);

        String title = Title.getText().toString();
        int price = Integer.parseInt(Price.getText().toString());

        String mess = "Book ("+ title + ") and the price (" + price+")";

        Toast.makeText(this,mess,Toast.LENGTH_SHORT).show();
    }
    public void onClearFieldsClick(View view){
        EditText Title = findViewById(R.id.Title);
        EditText Price = findViewById(R.id.Price);
        EditText BookId = findViewById(R.id.bookID);
        EditText ISBN = findViewById(R.id.ISBN);
        EditText Desc = findViewById(R.id.Description);
        EditText Author = findViewById(R.id.Author);

        Author.getText().clear();
        Title.getText().clear();
        Price.getText().clear();
        BookId.getText().clear();
        ISBN.getText().clear();
        Desc.getText().clear();
    }
}


